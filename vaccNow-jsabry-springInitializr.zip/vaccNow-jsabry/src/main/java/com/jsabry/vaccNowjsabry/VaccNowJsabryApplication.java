package com.jsabry.vaccNowjsabry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VaccNowJsabryApplication {

	public static void main(String[] args) {
		SpringApplication.run(VaccNowJsabryApplication.class, args);
	}

}
