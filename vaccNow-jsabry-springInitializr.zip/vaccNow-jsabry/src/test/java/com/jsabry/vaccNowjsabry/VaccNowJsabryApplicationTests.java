package com.jsabry.vaccNowjsabry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VaccNowJsabryApplicationTests {

	@Test
	void contextLoads() {
	}

}
